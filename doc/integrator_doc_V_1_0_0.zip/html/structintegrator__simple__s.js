var structintegrator__simple__s =
[
    [ "dt", "structintegrator__simple__s.html#aec75ed6ff36e092303b40684b734c475", null ],
    [ "is_init", "structintegrator__simple__s.html#a4ea1602cae0dcda4e4aa569a6db0fb1f", null ],
    [ "y", "structintegrator__simple__s.html#a035c18209e4f41880b8f388236985e17", null ]
];