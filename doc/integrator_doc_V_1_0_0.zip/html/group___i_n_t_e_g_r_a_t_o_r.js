var group___i_n_t_e_g_r_a_t_o_r =
[
    [ "integrator_simple_s", "structintegrator__simple__s.html", [
      [ "dt", "structintegrator__simple__s.html#aec75ed6ff36e092303b40684b734c475", null ],
      [ "is_init", "structintegrator__simple__s.html#a4ea1602cae0dcda4e4aa569a6db0fb1f", null ],
      [ "y", "structintegrator__simple__s.html#a035c18209e4f41880b8f388236985e17", null ]
    ] ],
    [ "integrator_trapezoid_s", "structintegrator__trapezoid__s.html", [
      [ "dt", "structintegrator__trapezoid__s.html#aa8878b3a157a722ae6d9dd280326ff9a", null ],
      [ "is_init", "structintegrator__trapezoid__s.html#a396bd81625691456e854b3d698a1635e", null ],
      [ "x_prev", "structintegrator__trapezoid__s.html#ad8ad51c91a41f9fd10631fbd2b02775f", null ],
      [ "y", "structintegrator__trapezoid__s.html#a9c31c5b28a0345fbcf2c0bc479f6082e", null ]
    ] ],
    [ "integrator_simple_t", "group___i_n_t_e_g_r_a_t_o_r.html#gad96948a725ec6ea5a4afd86b3982ada8", null ],
    [ "integrator_trapezoid_t", "group___i_n_t_e_g_r_a_t_o_r.html#gaeb556889b1c9b05398cae309c8c50120", null ]
];