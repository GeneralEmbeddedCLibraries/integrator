var annotated_dup =
[
    [ "integrator_simple_s", "structintegrator__simple__s.html", "structintegrator__simple__s" ],
    [ "integrator_trapezoid_s", "structintegrator__trapezoid__s.html", "structintegrator__trapezoid__s" ]
];