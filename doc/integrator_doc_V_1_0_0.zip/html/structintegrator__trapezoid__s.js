var structintegrator__trapezoid__s =
[
    [ "dt", "structintegrator__trapezoid__s.html#aa8878b3a157a722ae6d9dd280326ff9a", null ],
    [ "is_init", "structintegrator__trapezoid__s.html#a396bd81625691456e854b3d698a1635e", null ],
    [ "x_prev", "structintegrator__trapezoid__s.html#ad8ad51c91a41f9fd10631fbd2b02775f", null ],
    [ "y", "structintegrator__trapezoid__s.html#a9c31c5b28a0345fbcf2c0bc479f6082e", null ]
];